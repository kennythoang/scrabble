public enum Space {
	DW, DL, TW, TL, N; 
}